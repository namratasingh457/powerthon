import { useState } from "react";
import { useLocation } from "wouter";
import { Check, Lock, TrendingUp, Shield, Zap, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAppStore } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import type { SubscriptionTier } from "@shared/schema";

export default function Pricing() {
  const [, navigate] = useLocation();
  const { subscription, setSubscription, setUser } = useAppStore();
  const { toast } = useToast();
  const [billingPeriod, setBillingPeriod] = useState<"monthly" | "yearly">("monthly");
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier | null>(null);
  const [showSignupDialog, setShowSignupDialog] = useState(false);

  const [signupForm, setSignupForm] = useState({
    username: "",
    email: "",
    password: "",
  });

  const { data: tiers, isLoading } = useQuery<SubscriptionTier[]>({
    queryKey: ["/api/subscription-tiers"],
  });

  const subscribeMutation = useMutation({
    mutationFn: async (data: { tierId: string; username: string; email: string }) => {
      return apiRequest("POST", "/api/subscribe", data);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      setUser(data.user);
      setSubscription(data.subscription);
      setShowSignupDialog(false);
      toast({
        title: "Subscription activated!",
        description: `Welcome to ${data.subscription.name}! Your prices are now locked.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/price-locks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      navigate("/dashboard");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to activate subscription. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSelectTier = (tier: SubscriptionTier) => {
    setSelectedTier(tier);
    setShowSignupDialog(true);
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTier) return;
    subscribeMutation.mutate({
      tierId: selectedTier.id,
      username: signupForm.username,
      email: signupForm.email,
    });
  };

  const filteredTiers = tiers?.filter((tier) => tier.period === billingPeriod) || [];

  const faqItems = [
    {
      question: "How does price locking work?",
      answer: "When you subscribe, the current prices of all products are saved for you. Even if market prices increase, you continue paying your locked prices as long as you maintain your subscription.",
    },
    {
      question: "What happens if I cancel my subscription?",
      answer: "If you cancel, your locked prices are removed. When you resubscribe, new prices will be locked based on current market rates at that time.",
    },
    {
      question: "Can I change my subscription tier?",
      answer: "Yes, you can upgrade or downgrade your subscription at any time. Upgrading gives you access to more price locks immediately.",
    },
    {
      question: "Is there a free trial?",
      answer: "Yes! All paid plans include a 7-day free trial. You can cancel anytime before the trial ends without being charged.",
    },
  ];

  return (
    <div className="min-h-screen">
      <section className="bg-gradient-to-b from-muted/50 to-background py-16">
        <div className="mx-auto max-w-7xl px-4 text-center">
          <Badge variant="secondary" className="mb-4">
            7-Day Free Trial on All Plans
          </Badge>
          <h1 className="text-4xl font-bold mb-4 md:text-5xl">
            Choose Your Subscription Plan
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Lock in today's prices and save on every purchase. The more you shop, the more you save.
          </p>

          <Tabs value={billingPeriod} onValueChange={(v) => setBillingPeriod(v as "monthly" | "yearly")} className="inline-flex">
            <TabsList>
              <TabsTrigger value="monthly" data-testid="tab-monthly">Monthly</TabsTrigger>
              <TabsTrigger value="yearly" data-testid="tab-yearly">
                Yearly
                <Badge variant="default" className="ml-2">Save 20%</Badge>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4">
          {isLoading ? (
            <div className="grid gap-8 md:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-8 w-24 mx-auto" />
                    <Skeleton className="h-12 w-32 mx-auto mt-4" />
                  </CardHeader>
                  <CardContent>
                    {[1, 2, 3, 4].map((j) => (
                      <Skeleton key={j} className="h-6 w-full mb-3" />
                    ))}
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-10 w-full" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid gap-8 md:grid-cols-3">
              {filteredTiers.map((tier) => {
                const isCurrentPlan = subscription?.id === tier.id;
                
                return (
                  <Card
                    key={tier.id}
                    className={`relative flex flex-col ${tier.popular ? "border-primary ring-1 ring-primary" : ""}`}
                    data-testid={`card-tier-${tier.id}`}
                  >
                    {tier.popular && (
                      <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                        <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                      </div>
                    )}

                    <CardHeader className="text-center pt-8">
                      <CardTitle className="text-2xl">{tier.name}</CardTitle>
                      <CardDescription>
                        {tier.discountPercent > 0
                          ? `${tier.discountPercent}% off all products`
                          : "Explore price locking benefits"}
                      </CardDescription>
                      <div className="mt-4">
                        <span className="text-4xl font-bold">${tier.price}</span>
                        <span className="text-muted-foreground">/{tier.period}</span>
                      </div>
                    </CardHeader>

                    <CardContent className="flex-1">
                      <ul className="space-y-3">
                        {tier.features.map((feature, index) => (
                          <li key={index} className="flex items-start gap-3">
                            <Check className="h-5 w-5 text-success shrink-0 mt-0.5" />
                            <span className="text-sm">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>

                    <CardFooter>
                      <Button
                        className="w-full"
                        variant={tier.popular ? "default" : "outline"}
                        onClick={() => handleSelectTier(tier)}
                        disabled={isCurrentPlan}
                        data-testid={`button-select-${tier.id}`}
                      >
                        {isCurrentPlan ? "Current Plan" : "Get Started"}
                      </Button>
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Subscribe?</h2>
          <div className="grid gap-8 md:grid-cols-4">
            {[
              { icon: Lock, title: "Lock Prices", desc: "Freeze current prices forever" },
              { icon: TrendingUp, title: "Beat Inflation", desc: "Save as prices rise" },
              { icon: Shield, title: "Guaranteed", desc: "Price protection promise" },
              { icon: Zap, title: "Instant Access", desc: "Immediate benefits" },
            ].map((item, i) => (
              <Card key={i} className="text-center">
                <CardContent className="pt-6">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <item.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-3xl px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {faqItems.map((item, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">{item.question}</h3>
                  <p className="text-muted-foreground">{item.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Dialog open={showSignupDialog} onOpenChange={setShowSignupDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Complete Your Subscription</DialogTitle>
            <DialogDescription>
              {selectedTier && (
                <>
                  You're signing up for <strong>{selectedTier.name}</strong> at ${selectedTier.price}/{selectedTier.period}
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSubscribe}>
            <div className="space-y-4 py-4">
              <Card className="bg-muted/50">
                <CardContent className="p-3 flex items-center gap-2 text-sm">
                  <Lock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">
                    This is a demo signup. No real payment will be processed.
                  </span>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <Label htmlFor="signup-username">Username</Label>
                <Input
                  id="signup-username"
                  value={signupForm.username}
                  onChange={(e) => setSignupForm({ ...signupForm, username: e.target.value })}
                  required
                  data-testid="input-signup-username"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="signup-email">Email</Label>
                <Input
                  id="signup-email"
                  type="email"
                  value={signupForm.email}
                  onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                  required
                  data-testid="input-signup-email"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="signup-password">Password</Label>
                <Input
                  id="signup-password"
                  type="password"
                  value={signupForm.password}
                  onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                  required
                  data-testid="input-signup-password"
                />
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowSignupDialog(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={subscribeMutation.isPending} data-testid="button-confirm-subscription">
                {subscribeMutation.isPending ? "Processing..." : "Start Subscription"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
