import { Link } from "wouter";
import { Lock, TrendingUp, Shield, Zap, ArrowRight, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ProductCard } from "@/components/product-card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/lib/store";
import type { ProductWithPriceLock } from "@shared/schema";

export default function Home() {
  const { user } = useAppStore();
  const { data: products, isLoading } = useQuery<ProductWithPriceLock[]>({
    queryKey: ["/api/products", user?.id],
    queryFn: async () => {
      const params = user?.id ? `?userId=${user.id}` : "";
      const res = await fetch(`/api/products${params}`);
      if (!res.ok) throw new Error("Failed to fetch products");
      return res.json();
    },
  });

  const featuredProducts = products?.slice(0, 4) || [];

  const features = [
    {
      icon: Lock,
      title: "Lock Your Prices",
      description: "When you subscribe, current product prices are frozen for you - even when market prices rise.",
    },
    {
      icon: TrendingUp,
      title: "Beat Inflation",
      description: "While others pay more, you continue to buy at the prices you locked in. Save more every month.",
    },
    {
      icon: Shield,
      title: "Price Guarantee",
      description: "Your locked prices are guaranteed for as long as you maintain your subscription.",
    },
    {
      icon: Zap,
      title: "Instant Savings",
      description: "See your savings in real-time as market prices increase but yours stay the same.",
    },
  ];

  const stats = [
    { value: "10,000+", label: "Active Subscribers" },
    { value: "$2.5M+", label: "Total Savings" },
    { value: "500+", label: "Products Available" },
    { value: "98%", label: "Customer Satisfaction" },
  ];

  return (
    <div className="flex flex-col">
      <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-muted" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
        
        <div className="relative mx-auto max-w-7xl px-4 py-24 text-center">
          <Badge variant="secondary" className="mb-6">
            New: VIP Tier with Unlimited Price Locks
          </Badge>
          
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl mb-6">
            Lock Today's Prices.
            <br />
            <span className="text-primary">Save Forever.</span>
          </h1>
          
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground mb-8">
            Subscribe to freeze current product prices, no matter how much they increase in the future. 
            The longer you stay, the more you save.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/pricing">
              <Button size="lg" className="gap-2" data-testid="button-hero-start">
                Start Free Trial
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/products">
              <Button size="lg" variant="outline" data-testid="button-hero-browse">
                Browse Products
              </Button>
            </Link>
          </div>

          <div className="mt-16 grid grid-cols-2 gap-6 sm:grid-cols-4">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl font-bold sm:text-3xl text-primary" data-testid={`stat-value-${index}`}>
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How Price Locking Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Simple, transparent, and designed to save you money on every purchase
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-6">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Products</h2>
              <p className="text-muted-foreground">
                Lock in these prices before they go up
              </p>
            </div>
            <Link href="/products">
              <Button variant="outline" className="gap-2" data-testid="link-view-all-products">
                View All Products
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          {isLoading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i}>
                  <Skeleton className="aspect-square" />
                  <CardContent className="p-4">
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <Skeleton className="h-6 w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-20 bg-primary text-primary-foreground">
        <div className="mx-auto max-w-4xl px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Lock in Your Savings?
          </h2>
          <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
            Join thousands of smart shoppers who are saving money by locking in today's prices.
            Start your free trial and see the difference.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/pricing">
              <Button size="lg" variant="secondary" className="gap-2" data-testid="button-cta-subscribe">
                View Subscription Plans
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm opacity-80">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span>No credit card required</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span>Cancel anytime</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span>30-day money back</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
