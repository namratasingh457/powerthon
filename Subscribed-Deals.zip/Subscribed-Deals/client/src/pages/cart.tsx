import { Link } from "wouter";
import { ShoppingCart, Trash2, Minus, Plus, ArrowRight, Lock, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useAppStore } from "@/lib/store";

export default function Cart() {
  const { cartItems, updateCartItem, removeFromCart, subscription } = useAppStore();

  const subtotal = cartItems.reduce((sum, item) => sum + item.effectivePrice * item.quantity, 0);
  const totalSavings = cartItems.reduce((sum, item) => sum + item.savings, 0);
  const total = subtotal;

  if (cartItems.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-muted">
            <ShoppingBag className="h-10 w-10 text-muted-foreground" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6 max-w-sm">
            Looks like you haven't added any products yet. Start shopping to lock in great prices!
          </p>
          <Link href="/products">
            <Button className="gap-2" data-testid="button-start-shopping">
              Start Shopping
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="bg-muted/30 py-12">
        <div className="mx-auto max-w-7xl px-4">
          <h1 className="text-3xl font-bold mb-2">Shopping Cart</h1>
          <p className="text-muted-foreground">
            {cartItems.length} item{cartItems.length !== 1 ? "s" : ""} in your cart
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => {
              const hasLockedPrice = item.lockedPrice !== undefined && item.lockedPrice < item.product.currentPrice;
              
              return (
                <Card key={item.id} data-testid={`cart-item-${item.productId}`}>
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <Link href={`/products/${item.productId}`}>
                        <div className="h-24 w-24 overflow-hidden rounded-md bg-muted shrink-0">
                          <img
                            src={item.product.imageUrl}
                            alt={item.product.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                      </Link>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <Link href={`/products/${item.productId}`}>
                              <h3 className="font-semibold truncate hover:text-primary transition-colors">
                                {item.product.name}
                              </h3>
                            </Link>
                            <p className="text-sm text-muted-foreground">{item.product.category}</p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeFromCart(item.productId)}
                            data-testid={`button-remove-${item.productId}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>

                        <div className="mt-3 flex items-center justify-between gap-4 flex-wrap">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => updateCartItem(item.productId, Math.max(1, item.quantity - 1))}
                              disabled={item.quantity <= 1}
                              data-testid={`button-decrease-${item.productId}`}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-8 text-center font-medium">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => updateCartItem(item.productId, item.quantity + 1)}
                              data-testid={`button-increase-${item.productId}`}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>

                          <div className="text-right">
                            <div className="flex items-baseline gap-2 flex-wrap justify-end">
                              <span className="font-bold text-lg">
                                ${(item.effectivePrice * item.quantity).toFixed(2)}
                              </span>
                              {hasLockedPrice && (
                                <span className="text-sm text-muted-foreground line-through">
                                  ${(item.product.currentPrice * item.quantity).toFixed(2)}
                                </span>
                              )}
                            </div>
                            {hasLockedPrice && (
                              <Badge variant="outline" className="text-success border-success mt-1">
                                <Lock className="h-3 w-3 mr-1" />
                                Saving ${(item.savings).toFixed(2)}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>

                {totalSavings > 0 && (
                  <div className="flex justify-between text-success">
                    <span className="flex items-center gap-1">
                      <Lock className="h-4 w-4" />
                      Price Lock Savings
                    </span>
                    <span className="font-semibold">-${totalSavings.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span className="text-success">Free</span>
                </div>

                <Separator />

                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>

                {!subscription && (
                  <Card className="bg-muted/50">
                    <CardContent className="p-3">
                      <p className="text-sm text-center">
                        <Link href="/pricing" className="text-primary hover:underline font-medium">
                          Subscribe now
                        </Link>
                        {" "}to lock in prices and save even more on future purchases!
                      </p>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
              <CardFooter className="flex-col gap-3">
                <Link href="/checkout" className="w-full">
                  <Button className="w-full gap-2" size="lg" data-testid="button-checkout">
                    Proceed to Checkout
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/products" className="w-full">
                  <Button variant="outline" className="w-full" data-testid="button-continue-shopping">
                    Continue Shopping
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
