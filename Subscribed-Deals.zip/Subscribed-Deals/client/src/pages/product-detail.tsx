import { useRoute, Link } from "wouter";
import { ArrowLeft, ShoppingCart, Lock, TrendingUp, Shield, Minus, Plus, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useAppStore } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithPriceLock } from "@shared/schema";

export default function ProductDetail() {
  const [, params] = useRoute("/products/:id");
  const productId = params?.id;
  const [quantity, setQuantity] = useState(1);
  const { user, subscription, addToCart } = useAppStore();
  const { toast } = useToast();

  const { data: product, isLoading } = useQuery<ProductWithPriceLock>({
    queryKey: ["/api/products", productId, user?.id],
    queryFn: async () => {
      const params = user?.id ? `?userId=${user.id}` : "";
      const res = await fetch(`/api/products/${productId}${params}`);
      if (!res.ok) throw new Error("Failed to fetch product");
      return res.json();
    },
    enabled: !!productId,
  });

  if (isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8">
        <Skeleton className="h-8 w-32 mb-8" />
        <div className="grid gap-8 lg:grid-cols-2">
          <Skeleton className="aspect-square rounded-lg" />
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <Link href="/products">
          <Button>Back to Products</Button>
        </Link>
      </div>
    );
  }

  const hasLockedPrice = product.lockedPrice !== undefined && product.lockedPrice < product.currentPrice;
  const effectivePrice = hasLockedPrice ? product.lockedPrice! : product.currentPrice;
  const savingsAmount = product.currentPrice - effectivePrice;
  const savingsPercent = Math.round((savingsAmount / product.currentPrice) * 100);
  const totalPrice = effectivePrice * quantity;
  const totalSavings = savingsAmount * quantity;

  const handleAddToCart = () => {
    addToCart({
      id: `cart-${product.id}-${Date.now()}`,
      userId: "guest",
      productId: product.id,
      quantity,
      priceAtAdd: effectivePrice,
      product,
      lockedPrice: product.lockedPrice,
      effectivePrice,
      savings: savingsAmount * quantity,
    });
    toast({
      title: "Added to cart",
      description: `${quantity}x ${product.name} has been added to your cart.`,
    });
  };

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <Link href="/products">
          <Button variant="ghost" className="mb-6 gap-2" data-testid="button-back">
            <ArrowLeft className="h-4 w-4" />
            Back to Products
          </Button>
        </Link>

        <div className="grid gap-8 lg:grid-cols-2">
          <div className="relative">
            <div className="aspect-square overflow-hidden rounded-lg bg-muted">
              <img
                src={product.imageUrl}
                alt={product.name}
                className="h-full w-full object-cover"
              />
            </div>
            {hasLockedPrice && (
              <div className="absolute top-4 right-4">
                <Badge className="bg-success text-success-foreground text-lg px-4 py-2 gap-2">
                  <Lock className="h-4 w-4" />
                  Price Locked - {savingsPercent}% OFF
                </Badge>
              </div>
            )}
          </div>

          <div className="flex flex-col">
            <Badge variant="secondary" className="w-fit mb-2">
              {product.category}
            </Badge>

            <h1 className="text-3xl font-bold mb-4" data-testid="text-product-title">
              {product.name}
            </h1>

            <div className="flex items-baseline gap-3 mb-4 flex-wrap">
              <span className="text-4xl font-bold" data-testid="text-product-price">
                ${effectivePrice.toFixed(2)}
              </span>
              {hasLockedPrice && (
                <>
                  <span className="text-xl text-muted-foreground line-through">
                    ${product.currentPrice.toFixed(2)}
                  </span>
                  <Badge className="bg-success text-success-foreground">
                    Save ${savingsAmount.toFixed(2)}
                  </Badge>
                </>
              )}
            </div>

            {hasLockedPrice ? (
              <Card className="mb-6 border-success">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-success/10">
                    <Lock className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="font-semibold text-success">Your Price is Locked!</p>
                    <p className="text-sm text-muted-foreground">
                      Market price is ${product.currentPrice.toFixed(2)}, but you pay ${effectivePrice.toFixed(2)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="mb-6">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                    <TrendingUp className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-semibold">Price May Increase</p>
                    <p className="text-sm text-muted-foreground">
                      <Link href="/pricing" className="text-primary hover:underline">
                        Subscribe now
                      </Link>
                      {" "}to lock in today's price forever
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            <p className="text-muted-foreground mb-6">{product.description}</p>

            <Separator className="mb-6" />

            <div className="flex items-center gap-4 mb-6">
              <span className="font-medium">Quantity:</span>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                  data-testid="button-decrease-quantity"
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="w-12 text-center font-semibold" data-testid="text-quantity">
                  {quantity}
                </span>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(quantity + 1)}
                  data-testid="button-increase-quantity"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <Card className="mb-6 bg-muted/50">
              <CardContent className="p-4">
                <div className="flex justify-between mb-2">
                  <span>Subtotal ({quantity} item{quantity > 1 ? "s" : ""})</span>
                  <span className="font-semibold">${totalPrice.toFixed(2)}</span>
                </div>
                {totalSavings > 0 && (
                  <div className="flex justify-between text-success">
                    <span>Your Savings</span>
                    <span className="font-semibold">-${totalSavings.toFixed(2)}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            <Button
              size="lg"
              className="w-full gap-2"
              onClick={handleAddToCart}
              disabled={!product.inStock}
              data-testid="button-add-to-cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {product.inStock ? "Add to Cart" : "Out of Stock"}
            </Button>

            <div className="mt-6 grid grid-cols-3 gap-4 text-center">
              <div className="flex flex-col items-center gap-1">
                <Shield className="h-5 w-5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Secure Payment</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <Lock className="h-5 w-5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Price Guarantee</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <Check className="h-5 w-5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">Quality Assured</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
