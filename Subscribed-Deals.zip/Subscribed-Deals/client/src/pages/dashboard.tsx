import { Link } from "wouter";
import { Lock, TrendingUp, ShoppingBag, CreditCard, ArrowRight, Package, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { useAppStore } from "@/lib/store";
import type { ProductWithPriceLock, Order, PriceLock } from "@shared/schema";

export default function Dashboard() {
  const { user, subscription, setSubscription, setUser } = useAppStore();

  const { data: products, isLoading: productsLoading } = useQuery<ProductWithPriceLock[]>({
    queryKey: ["/api/products", user?.id],
    queryFn: async () => {
      const params = user?.id ? `?userId=${user.id}` : "";
      const res = await fetch(`/api/products${params}`);
      if (!res.ok) throw new Error("Failed to fetch products");
      return res.json();
    },
    enabled: !!user,
  });

  const { data: priceLocks, isLoading: locksLoading } = useQuery<PriceLock[]>({
    queryKey: ["/api/price-locks", user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/price-locks?userId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch price locks");
      return res.json();
    },
    enabled: !!user,
  });

  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders", user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/orders?userId=${user?.id}`);
      if (!res.ok) throw new Error("Failed to fetch orders");
      return res.json();
    },
    enabled: !!user,
  });

  const lockedProducts = products?.filter(p => p.lockedPrice !== undefined) || [];
  const totalSavings = lockedProducts.reduce((sum, p) => {
    if (p.lockedPrice && p.lockedPrice < p.currentPrice) {
      return sum + (p.currentPrice - p.lockedPrice);
    }
    return sum;
  }, 0);

  const maxPriceLocks = subscription?.maxPriceLocks || 0;
  const usedPriceLocks = priceLocks?.length || 0;
  const lockUsagePercent = maxPriceLocks > 0 ? (usedPriceLocks / maxPriceLocks) * 100 : 0;

  if (!user && !subscription) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="pt-6 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
              <AlertCircle className="h-8 w-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-bold mb-2">No Active Subscription</h2>
            <p className="text-muted-foreground mb-6">
              Subscribe to start locking in prices and access your personalized dashboard.
            </p>
            <Link href="/pricing">
              <Button className="gap-2" data-testid="button-view-plans">
                View Subscription Plans
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="bg-muted/30 py-12">
        <div className="mx-auto max-w-7xl px-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-3xl font-bold mb-2">Welcome back, {user?.username || "Subscriber"}!</h1>
              <p className="text-muted-foreground">
                Manage your subscription and track your savings
              </p>
            </div>
            {subscription && (
              <Badge className="text-base py-2 px-4" data-testid="badge-subscription-tier">
                {subscription.name} Plan
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-success/10">
                  <Lock className="h-6 w-6 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Locked Products</p>
                  <p className="text-2xl font-bold" data-testid="stat-locked-products">{lockedProducts.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Savings</p>
                  <p className="text-2xl font-bold text-success" data-testid="stat-total-savings">
                    ${totalSavings.toFixed(2)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                  <ShoppingBag className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Orders</p>
                  <p className="text-2xl font-bold" data-testid="stat-orders">{orders?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                  <CreditCard className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Cost</p>
                  <p className="text-2xl font-bold" data-testid="stat-monthly-cost">
                    ${subscription?.price.toFixed(2) || "0.00"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="locked-prices" className="space-y-6">
          <TabsList>
            <TabsTrigger value="locked-prices" data-testid="tab-locked-prices">Locked Prices</TabsTrigger>
            <TabsTrigger value="subscription" data-testid="tab-subscription">Subscription</TabsTrigger>
            <TabsTrigger value="orders" data-testid="tab-orders">Orders</TabsTrigger>
          </TabsList>

          <TabsContent value="locked-prices">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div>
                    <CardTitle>Your Locked Prices</CardTitle>
                    <CardDescription>Products with prices frozen at your subscription rate</CardDescription>
                  </div>
                  {maxPriceLocks > 0 && (
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground mb-1">
                        {usedPriceLocks} of {maxPriceLocks === 999 ? "Unlimited" : maxPriceLocks} price locks used
                      </p>
                      {maxPriceLocks !== 999 && (
                        <Progress value={lockUsagePercent} className="w-32 h-2" />
                      )}
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {productsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center gap-4">
                        <Skeleton className="h-16 w-16 rounded-md" />
                        <div className="flex-1">
                          <Skeleton className="h-5 w-1/3 mb-2" />
                          <Skeleton className="h-4 w-1/4" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : lockedProducts.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">
                      No price locks yet. Browse products to see your locked prices.
                    </p>
                    <Link href="/products">
                      <Button variant="outline">Browse Products</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {lockedProducts.map((product) => {
                      const savings = product.currentPrice - (product.lockedPrice || product.currentPrice);
                      const savingsPercent = Math.round((savings / product.currentPrice) * 100);
                      
                      return (
                        <div
                          key={product.id}
                          className="flex items-center gap-4 p-4 rounded-lg bg-muted/50"
                          data-testid={`locked-product-${product.id}`}
                        >
                          <Link href={`/products/${product.id}`}>
                            <div className="h-16 w-16 overflow-hidden rounded-md bg-muted shrink-0">
                              <img
                                src={product.imageUrl}
                                alt={product.name}
                                className="h-full w-full object-cover"
                              />
                            </div>
                          </Link>
                          <div className="flex-1 min-w-0">
                            <Link href={`/products/${product.id}`}>
                              <h3 className="font-semibold truncate hover:text-primary transition-colors">
                                {product.name}
                              </h3>
                            </Link>
                            <p className="text-sm text-muted-foreground">{product.category}</p>
                          </div>
                          <div className="text-right shrink-0">
                            <div className="flex items-baseline gap-2 flex-wrap justify-end">
                              <span className="text-lg font-bold">
                                ${product.lockedPrice?.toFixed(2)}
                              </span>
                              <span className="text-sm text-muted-foreground line-through">
                                ${product.currentPrice.toFixed(2)}
                              </span>
                            </div>
                            {savings > 0 && (
                              <Badge className="bg-success text-success-foreground mt-1">
                                Save {savingsPercent}%
                              </Badge>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Link href="/products" className="w-full">
                  <Button variant="outline" className="w-full gap-2">
                    Browse All Products
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="subscription">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Current Plan</CardTitle>
                  <CardDescription>Your active subscription details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {subscription ? (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Plan</span>
                        <span className="font-semibold">{subscription.name}</span>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Price</span>
                        <span className="font-semibold">${subscription.price}/{subscription.period}</span>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Discount</span>
                        <span className="font-semibold text-success">{subscription.discountPercent}% off</span>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Price Locks</span>
                        <span className="font-semibold">
                          {subscription.maxPriceLocks === 999 ? "Unlimited" : subscription.maxPriceLocks}
                        </span>
                      </div>
                    </>
                  ) : (
                    <p className="text-muted-foreground">No active subscription</p>
                  )}
                </CardContent>
                <CardFooter>
                  <Link href="/pricing" className="w-full">
                    <Button variant="outline" className="w-full">
                      {subscription ? "Change Plan" : "Subscribe Now"}
                    </Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Plan Benefits</CardTitle>
                  <CardDescription>Features included in your plan</CardDescription>
                </CardHeader>
                <CardContent>
                  {subscription ? (
                    <ul className="space-y-3">
                      {subscription.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <Lock className="h-5 w-5 text-success shrink-0 mt-0.5" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-muted-foreground">Subscribe to unlock benefits</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Order History</CardTitle>
                <CardDescription>Your past purchases and savings</CardDescription>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-20 w-full" />
                    ))}
                  </div>
                ) : !orders || orders.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                      <Package className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <p className="text-muted-foreground mb-4">No orders yet</p>
                    <Link href="/products">
                      <Button variant="outline">Start Shopping</Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div
                        key={order.id}
                        className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                        data-testid={`order-${order.id}`}
                      >
                        <div>
                          <p className="font-semibold">Order #{order.id.slice(0, 8)}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(order.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold">${order.total.toFixed(2)}</p>
                          {order.savings > 0 && (
                            <Badge variant="outline" className="text-success border-success">
                              Saved ${order.savings.toFixed(2)}
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
