import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, SubscriptionTier, CartItemWithProduct } from '@shared/schema';

interface AppState {
  user: User | null;
  subscription: SubscriptionTier | null;
  cartItems: CartItemWithProduct[];
  theme: 'light' | 'dark';
  
  setUser: (user: User | null) => void;
  setSubscription: (subscription: SubscriptionTier | null) => void;
  setCartItems: (items: CartItemWithProduct[]) => void;
  addToCart: (item: CartItemWithProduct) => void;
  updateCartItem: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  toggleTheme: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      user: null,
      subscription: null,
      cartItems: [],
      theme: 'light',
      
      setUser: (user) => set({ user }),
      setSubscription: (subscription) => set({ subscription }),
      setCartItems: (cartItems) => set({ cartItems }),
      
      addToCart: (item) => set((state) => {
        const existingIndex = state.cartItems.findIndex(
          (i) => i.productId === item.productId
        );
        if (existingIndex >= 0) {
          const newItems = [...state.cartItems];
          newItems[existingIndex] = {
            ...newItems[existingIndex],
            quantity: newItems[existingIndex].quantity + item.quantity,
          };
          return { cartItems: newItems };
        }
        return { cartItems: [...state.cartItems, item] };
      }),
      
      updateCartItem: (productId, quantity) => set((state) => ({
        cartItems: state.cartItems.map((item) =>
          item.productId === productId ? { ...item, quantity } : item
        ),
      })),
      
      removeFromCart: (productId) => set((state) => ({
        cartItems: state.cartItems.filter((item) => item.productId !== productId),
      })),
      
      clearCart: () => set({ cartItems: [] }),
      
      toggleTheme: () => set((state) => {
        const newTheme = state.theme === 'light' ? 'dark' : 'light';
        if (newTheme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
        return { theme: newTheme };
      }),
      
      setTheme: (theme) => {
        if (theme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
        set({ theme });
      },
    }),
    {
      name: 'pricelock-store',
      onRehydrateStorage: () => (state) => {
        if (state?.theme === 'dark') {
          document.documentElement.classList.add('dark');
        }
      },
    }
  )
);
