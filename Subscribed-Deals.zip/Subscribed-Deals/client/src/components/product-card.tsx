import { Link } from "wouter";
import { ShoppingCart, Lock, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { ProductWithPriceLock } from "@shared/schema";
import { useAppStore } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: ProductWithPriceLock;
  onAddToCart?: (product: ProductWithPriceLock) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const { subscription, addToCart } = useAppStore();
  const { toast } = useToast();

  const hasLockedPrice = product.lockedPrice !== undefined && product.lockedPrice < product.currentPrice;
  const effectivePrice = hasLockedPrice ? product.lockedPrice! : product.currentPrice;
  const savingsAmount = product.currentPrice - effectivePrice;
  const savingsPercent = Math.round((savingsAmount / product.currentPrice) * 100);

  const handleAddToCart = () => {
    if (onAddToCart) {
      onAddToCart(product);
    } else {
      addToCart({
        id: `cart-${product.id}-${Date.now()}`,
        userId: "guest",
        productId: product.id,
        quantity: 1,
        priceAtAdd: effectivePrice,
        product,
        lockedPrice: product.lockedPrice,
        effectivePrice,
        savings: savingsAmount,
      });
      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart.`,
      });
    }
  };

  return (
    <Card className="group overflow-visible" data-testid={`card-product-${product.id}`}>
      <Link href={`/products/${product.id}`}>
        <div className="relative aspect-square overflow-hidden rounded-t-md bg-muted">
          <img
            src={product.imageUrl}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          {hasLockedPrice && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-success text-success-foreground gap-1">
                <Lock className="h-3 w-3" />
                {savingsPercent}% OFF
              </Badge>
            </div>
          )}
          {!subscription && (
            <div className="absolute top-2 left-2">
              <Badge variant="secondary" className="gap-1">
                <TrendingUp className="h-3 w-3" />
                Price may rise
              </Badge>
            </div>
          )}
        </div>
      </Link>

      <CardContent className="p-4">
        <Link href={`/products/${product.id}`}>
          <h3 className="font-semibold truncate hover:text-primary transition-colors" data-testid={`text-product-name-${product.id}`}>
            {product.name}
          </h3>
        </Link>
        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
          {product.description}
        </p>

        <div className="mt-3 flex items-baseline gap-2 flex-wrap">
          <span className="text-xl font-bold" data-testid={`text-price-${product.id}`}>
            ${effectivePrice.toFixed(2)}
          </span>
          {hasLockedPrice && (
            <>
              <span className="text-sm text-muted-foreground line-through">
                ${product.currentPrice.toFixed(2)}
              </span>
              <Badge variant="outline" className="text-success border-success">
                Save ${savingsAmount.toFixed(2)}
              </Badge>
            </>
          )}
        </div>

        {!subscription && (
          <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
            <Lock className="h-3 w-3" />
            Subscribe to lock this price
          </p>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button
          className="w-full"
          onClick={handleAddToCart}
          disabled={!product.inStock}
          data-testid={`button-add-to-cart-${product.id}`}
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          {product.inStock ? "Add to Cart" : "Out of Stock"}
        </Button>
      </CardFooter>
    </Card>
  );
}
