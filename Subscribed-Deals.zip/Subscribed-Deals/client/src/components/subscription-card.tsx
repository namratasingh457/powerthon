import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { SubscriptionTier } from "@shared/schema";
import { cn } from "@/lib/utils";

interface SubscriptionCardProps {
  tier: SubscriptionTier;
  isCurrentPlan?: boolean;
  onSelect: (tier: SubscriptionTier) => void;
  loading?: boolean;
}

export function SubscriptionCard({ tier, isCurrentPlan, onSelect, loading }: SubscriptionCardProps) {
  return (
    <Card
      className={cn(
        "relative flex flex-col",
        tier.popular && "border-primary ring-1 ring-primary"
      )}
      data-testid={`card-subscription-${tier.id}`}
    >
      {tier.popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
        </div>
      )}

      <CardHeader className="text-center pt-8">
        <CardTitle className="text-2xl">{tier.name}</CardTitle>
        <CardDescription>
          {tier.discountPercent > 0 
            ? `${tier.discountPercent}% off all products`
            : "Explore price locking benefits"}
        </CardDescription>
        <div className="mt-4">
          <span className="text-4xl font-bold">${tier.price}</span>
          <span className="text-muted-foreground">/{tier.period}</span>
        </div>
      </CardHeader>

      <CardContent className="flex-1">
        <ul className="space-y-3">
          {tier.features.map((feature, index) => (
            <li key={index} className="flex items-start gap-3">
              <Check className="h-5 w-5 text-success shrink-0 mt-0.5" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>

      <CardFooter>
        <Button
          className="w-full"
          variant={tier.popular ? "default" : "outline"}
          onClick={() => onSelect(tier)}
          disabled={loading || isCurrentPlan}
          data-testid={`button-select-${tier.id}`}
        >
          {isCurrentPlan ? "Current Plan" : loading ? "Processing..." : "Get Started"}
        </Button>
      </CardFooter>
    </Card>
  );
}
