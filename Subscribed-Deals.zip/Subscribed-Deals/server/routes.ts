import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Get all subscription tiers
  app.get("/api/subscription-tiers", async (req, res) => {
    try {
      const tiers = await storage.getSubscriptionTiers();
      res.json(tiers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch subscription tiers" });
    }
  });

  // Get single subscription tier
  app.get("/api/subscription-tiers/:id", async (req, res) => {
    try {
      const tier = await storage.getSubscriptionTier(req.params.id);
      if (!tier) {
        return res.status(404).json({ error: "Subscription tier not found" });
      }
      res.json(tier);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch subscription tier" });
    }
  });

  // Get all products (with price locks if user is subscribed)
  app.get("/api/products", async (req, res) => {
    try {
      const userId = req.query.userId as string | undefined;
      const products = await storage.getProductsWithPriceLocks(userId);
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const userId = req.query.userId as string | undefined;
      const product = await storage.getProductWithPriceLock(req.params.id, userId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Subscribe to a plan
  app.post("/api/subscribe", async (req, res) => {
    try {
      const subscribeSchema = z.object({
        tierId: z.string(),
        username: z.string().min(3),
        email: z.string().email(),
      });

      const { tierId, username, email } = subscribeSchema.parse(req.body);

      // Check if tier exists
      const tier = await storage.getSubscriptionTier(tierId);
      if (!tier) {
        return res.status(404).json({ error: "Subscription tier not found" });
      }

      // Check if user already exists
      let user = await storage.getUserByEmail(email);
      
      if (!user) {
        // Create new user
        user = await storage.createUser({
          username,
          email,
          password: "demo-password",
        });
      }

      // Update user subscription
      user = await storage.updateUserSubscription(user.id, tierId);
      if (!user) {
        return res.status(500).json({ error: "Failed to update subscription" });
      }

      // Create price locks for the user
      await storage.createPriceLocksForUser(user.id, tierId);

      res.json({ user, subscription: tier });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to process subscription" });
    }
  });

  // Get user's price locks
  app.get("/api/price-locks", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.json([]);
      }
      const locks = await storage.getPriceLocks(userId);
      res.json(locks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch price locks" });
    }
  });

  // Get user's orders
  app.get("/api/orders", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.json([]);
      }
      const orders = await storage.getOrders(userId);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  // Create order
  app.post("/api/orders", async (req, res) => {
    try {
      const orderSchema = z.object({
        userId: z.string(),
        total: z.number(),
        savings: z.number(),
        items: z.array(z.object({
          productId: z.string(),
          productName: z.string(),
          quantity: z.number(),
          pricePaid: z.number(),
          marketPrice: z.number(),
        })),
      });

      const { userId, total, savings, items } = orderSchema.parse(req.body);

      const order = await storage.createOrder({
        userId,
        total,
        savings,
        status: "completed",
        createdAt: new Date(),
      });

      // Create order items
      for (const item of items) {
        await storage.createOrderItem({
          orderId: order.id,
          ...item,
        });
      }

      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  // Cart operations
  app.get("/api/cart", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.json([]);
      }
      const items = await storage.getCartItems(userId);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch cart items" });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const cartItemSchema = z.object({
        userId: z.string(),
        productId: z.string(),
        quantity: z.number().min(1),
        priceAtAdd: z.number(),
      });

      const item = cartItemSchema.parse(req.body);
      const cartItem = await storage.addCartItem(item);
      res.json(cartItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to add item to cart" });
    }
  });

  app.patch("/api/cart/:id", async (req, res) => {
    try {
      const { quantity } = z.object({ quantity: z.number().min(1) }).parse(req.body);
      const item = await storage.updateCartItem(req.params.id, quantity);
      if (!item) {
        return res.status(404).json({ error: "Cart item not found" });
      }
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update cart item" });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      await storage.removeCartItem(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to remove cart item" });
    }
  });

  app.delete("/api/cart", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      if (!userId) {
        return res.status(400).json({ error: "User ID is required" });
      }
      await storage.clearCart(userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear cart" });
    }
  });

  return httpServer;
}
