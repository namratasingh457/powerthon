import { 
  type User, type InsertUser, 
  type Product, type InsertProduct,
  type SubscriptionTier, type InsertSubscriptionTier,
  type PriceLock, type InsertPriceLock,
  type CartItem, type InsertCartItem,
  type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem,
  type ProductWithPriceLock
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserSubscription(userId: string, tierId: string): Promise<User | undefined>;

  // Subscription Tiers
  getSubscriptionTiers(): Promise<SubscriptionTier[]>;
  getSubscriptionTier(id: string): Promise<SubscriptionTier | undefined>;

  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  getProductsWithPriceLocks(userId?: string): Promise<ProductWithPriceLock[]>;
  getProductWithPriceLock(id: string, userId?: string): Promise<ProductWithPriceLock | undefined>;

  // Price Locks
  getPriceLocks(userId: string): Promise<PriceLock[]>;
  createPriceLock(priceLock: InsertPriceLock): Promise<PriceLock>;
  getPriceLockForProduct(userId: string, productId: string): Promise<PriceLock | undefined>;
  createPriceLocksForUser(userId: string, tierId: string): Promise<PriceLock[]>;

  // Cart Items
  getCartItems(userId: string): Promise<CartItem[]>;
  addCartItem(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: string): Promise<void>;
  clearCart(userId: string): Promise<void>;

  // Orders
  getOrders(userId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private subscriptionTiers: Map<string, SubscriptionTier>;
  private products: Map<string, Product>;
  private priceLocks: Map<string, PriceLock>;
  private cartItems: Map<string, CartItem>;
  private orders: Map<string, Order>;
  private orderItems: Map<string, OrderItem>;

  constructor() {
    this.users = new Map();
    this.subscriptionTiers = new Map();
    this.products = new Map();
    this.priceLocks = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();

    this.seedData();
  }

  private seedData() {
    // Seed subscription tiers
    const tiers: SubscriptionTier[] = [
      {
        id: "basic-monthly",
        name: "Basic",
        price: 9.99,
        period: "monthly",
        features: [
          "Lock up to 10 product prices",
          "5% discount on all products",
          "Email support",
          "Monthly price reports",
        ],
        maxPriceLocks: 10,
        discountPercent: 5,
        popular: false,
      },
      {
        id: "premium-monthly",
        name: "Premium",
        price: 19.99,
        period: "monthly",
        features: [
          "Lock up to 50 product prices",
          "10% discount on all products",
          "Priority support",
          "Weekly price reports",
          "Early access to sales",
        ],
        maxPriceLocks: 50,
        discountPercent: 10,
        popular: true,
      },
      {
        id: "vip-monthly",
        name: "VIP",
        price: 39.99,
        period: "monthly",
        features: [
          "Unlimited price locks",
          "15% discount on all products",
          "24/7 premium support",
          "Daily price alerts",
          "Exclusive VIP deals",
          "Free shipping on all orders",
        ],
        maxPriceLocks: 999,
        discountPercent: 15,
        popular: false,
      },
      {
        id: "basic-yearly",
        name: "Basic",
        price: 95.88,
        period: "yearly",
        features: [
          "Lock up to 10 product prices",
          "5% discount on all products",
          "Email support",
          "Monthly price reports",
          "2 months free",
        ],
        maxPriceLocks: 10,
        discountPercent: 5,
        popular: false,
      },
      {
        id: "premium-yearly",
        name: "Premium",
        price: 191.88,
        period: "yearly",
        features: [
          "Lock up to 50 product prices",
          "10% discount on all products",
          "Priority support",
          "Weekly price reports",
          "Early access to sales",
          "2 months free",
        ],
        maxPriceLocks: 50,
        discountPercent: 10,
        popular: true,
      },
      {
        id: "vip-yearly",
        name: "VIP",
        price: 383.88,
        period: "yearly",
        features: [
          "Unlimited price locks",
          "15% discount on all products",
          "24/7 premium support",
          "Daily price alerts",
          "Exclusive VIP deals",
          "Free shipping on all orders",
          "2 months free",
        ],
        maxPriceLocks: 999,
        discountPercent: 15,
        popular: false,
      },
    ];
    tiers.forEach((tier) => this.subscriptionTiers.set(tier.id, tier));

    // Seed products with realistic data
    const products: Product[] = [
      {
        id: "prod-1",
        name: "Wireless Bluetooth Headphones",
        description: "Premium noise-cancelling headphones with 30-hour battery life and crystal-clear sound quality.",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop",
        currentPrice: 199.99,
        originalPrice: 179.99,
        inStock: true,
      },
      {
        id: "prod-2",
        name: "Smart Fitness Watch",
        description: "Track your health with heart rate monitoring, GPS, and 7-day battery life.",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop",
        currentPrice: 299.99,
        originalPrice: 249.99,
        inStock: true,
      },
      {
        id: "prod-3",
        name: "Organic Coffee Beans",
        description: "Premium arabica beans from sustainable farms. Rich, smooth flavor with chocolate notes.",
        category: "Food & Beverage",
        imageUrl: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&h=400&fit=crop",
        currentPrice: 24.99,
        originalPrice: 19.99,
        inStock: true,
      },
      {
        id: "prod-4",
        name: "Ergonomic Office Chair",
        description: "Adjustable lumbar support, breathable mesh back, and premium comfort for all-day use.",
        category: "Home & Garden",
        imageUrl: "https://images.unsplash.com/photo-1592078615290-033ee584e267?w=400&h=400&fit=crop",
        currentPrice: 449.99,
        originalPrice: 399.99,
        inStock: true,
      },
      {
        id: "prod-5",
        name: "Professional Camera Lens",
        description: "50mm f/1.4 prime lens with exceptional sharpness and beautiful bokeh.",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1617005082133-548c4dd27f35?w=400&h=400&fit=crop",
        currentPrice: 899.99,
        originalPrice: 799.99,
        inStock: true,
      },
      {
        id: "prod-6",
        name: "Running Shoes Pro",
        description: "Lightweight, responsive cushioning designed for marathon runners.",
        category: "Sports",
        imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop",
        currentPrice: 179.99,
        originalPrice: 149.99,
        inStock: true,
      },
      {
        id: "prod-7",
        name: "Vitamin C Serum",
        description: "Brightening serum with 20% vitamin C for radiant, youthful skin.",
        category: "Beauty",
        imageUrl: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400&h=400&fit=crop",
        currentPrice: 49.99,
        originalPrice: 39.99,
        inStock: true,
      },
      {
        id: "prod-8",
        name: "Bestselling Novel Collection",
        description: "Award-winning fiction collection featuring 5 critically acclaimed novels.",
        category: "Books",
        imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=400&fit=crop",
        currentPrice: 59.99,
        originalPrice: 49.99,
        inStock: true,
      },
      {
        id: "prod-9",
        name: "Stainless Steel Water Bottle",
        description: "Double-walled insulation keeps drinks cold 24hrs or hot 12hrs.",
        category: "Sports",
        imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=400&h=400&fit=crop",
        currentPrice: 34.99,
        originalPrice: 29.99,
        inStock: true,
      },
      {
        id: "prod-10",
        name: "Wireless Charging Pad",
        description: "Fast 15W wireless charging compatible with all Qi-enabled devices.",
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1586816879360-004f5b0c51e5?w=400&h=400&fit=crop",
        currentPrice: 39.99,
        originalPrice: 34.99,
        inStock: true,
      },
      {
        id: "prod-11",
        name: "Indoor Plant Set",
        description: "Collection of 3 low-maintenance indoor plants with decorative pots.",
        category: "Home & Garden",
        imageUrl: "https://images.unsplash.com/photo-1463936575829-25148e1db1b8?w=400&h=400&fit=crop",
        currentPrice: 79.99,
        originalPrice: 69.99,
        inStock: true,
      },
      {
        id: "prod-12",
        name: "Premium Yoga Mat",
        description: "Extra thick, non-slip mat with alignment lines for perfect poses.",
        category: "Sports",
        imageUrl: "https://images.unsplash.com/photo-1592432678016-e910b452f9a2?w=400&h=400&fit=crop",
        currentPrice: 89.99,
        originalPrice: 79.99,
        inStock: true,
      },
    ];
    products.forEach((product) => this.products.set(product.id, product));
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      subscriptionTierId: null,
      subscribedAt: null,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserSubscription(userId: string, tierId: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    user.subscriptionTierId = tierId;
    user.subscribedAt = new Date();
    this.users.set(userId, user);
    return user;
  }

  // Subscription Tiers
  async getSubscriptionTiers(): Promise<SubscriptionTier[]> {
    return Array.from(this.subscriptionTiers.values());
  }

  async getSubscriptionTier(id: string): Promise<SubscriptionTier | undefined> {
    return this.subscriptionTiers.get(id);
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsWithPriceLocks(userId?: string): Promise<ProductWithPriceLock[]> {
    const products = Array.from(this.products.values());
    
    if (!userId) {
      return products.map(p => ({ ...p }));
    }

    const userLocks = Array.from(this.priceLocks.values()).filter(
      (lock) => lock.userId === userId
    );

    return products.map((product) => {
      const lock = userLocks.find((l) => l.productId === product.id);
      if (lock) {
        const savings = product.currentPrice - lock.lockedPrice;
        const savingsPercent = Math.round((savings / product.currentPrice) * 100);
        return {
          ...product,
          lockedPrice: lock.lockedPrice,
          savings,
          savingsPercent,
        };
      }
      return { ...product };
    });
  }

  async getProductWithPriceLock(id: string, userId?: string): Promise<ProductWithPriceLock | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;

    if (!userId) {
      return { ...product };
    }

    const lock = Array.from(this.priceLocks.values()).find(
      (l) => l.userId === userId && l.productId === id
    );

    if (lock) {
      const savings = product.currentPrice - lock.lockedPrice;
      const savingsPercent = Math.round((savings / product.currentPrice) * 100);
      return {
        ...product,
        lockedPrice: lock.lockedPrice,
        savings,
        savingsPercent,
      };
    }

    return { ...product };
  }

  // Price Locks
  async getPriceLocks(userId: string): Promise<PriceLock[]> {
    return Array.from(this.priceLocks.values()).filter(
      (lock) => lock.userId === userId
    );
  }

  async createPriceLock(priceLock: InsertPriceLock): Promise<PriceLock> {
    const id = randomUUID();
    const lock: PriceLock = { ...priceLock, id };
    this.priceLocks.set(id, lock);
    return lock;
  }

  async getPriceLockForProduct(userId: string, productId: string): Promise<PriceLock | undefined> {
    return Array.from(this.priceLocks.values()).find(
      (lock) => lock.userId === userId && lock.productId === productId
    );
  }

  async createPriceLocksForUser(userId: string, tierId: string): Promise<PriceLock[]> {
    const tier = await this.getSubscriptionTier(tierId);
    if (!tier) return [];

    const products = await this.getProducts();
    const locks: PriceLock[] = [];
    const maxLocks = tier.maxPriceLocks === 999 ? products.length : tier.maxPriceLocks;

    for (let i = 0; i < Math.min(products.length, maxLocks); i++) {
      const product = products[i];
      const discountedPrice = product.currentPrice * (1 - tier.discountPercent / 100);
      const lock = await this.createPriceLock({
        userId,
        productId: product.id,
        lockedPrice: Math.round(discountedPrice * 100) / 100,
        lockedAt: new Date(),
      });
      locks.push(lock);
    }

    return locks;
  }

  // Cart Items
  async getCartItems(userId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (item) => item.userId === userId
    );
  }

  async addCartItem(item: InsertCartItem): Promise<CartItem> {
    const id = randomUUID();
    const cartItem: CartItem = { ...item, id };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: string, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;
    item.quantity = quantity;
    this.cartItems.set(id, item);
    return item;
  }

  async removeCartItem(id: string): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(userId: string): Promise<void> {
    const toDelete = Array.from(this.cartItems.entries())
      .filter(([, item]) => item.userId === userId)
      .map(([id]) => id);
    toDelete.forEach((id) => this.cartItems.delete(id));
  }

  // Orders
  async getOrders(userId: string): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter((order) => order.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const newOrder: Order = { ...order, id };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async createOrderItem(item: InsertOrderItem): Promise<OrderItem> {
    const id = randomUUID();
    const orderItem: OrderItem = { ...item, id };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }
}

export const storage = new MemStorage();
