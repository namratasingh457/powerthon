import { pgTable, text, varchar, integer, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Subscription Tiers
export const subscriptionTiers = pgTable("subscription_tiers", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  price: real("price").notNull(),
  period: text("period").notNull(), // monthly, yearly
  features: text("features").array().notNull(),
  maxPriceLocks: integer("max_price_locks").notNull(),
  discountPercent: real("discount_percent").notNull(),
  popular: boolean("popular").default(false),
});

export const insertSubscriptionTierSchema = createInsertSchema(subscriptionTiers);
export type InsertSubscriptionTier = z.infer<typeof insertSubscriptionTierSchema>;
export type SubscriptionTier = typeof subscriptionTiers.$inferSelect;

// Users
export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  subscriptionTierId: varchar("subscription_tier_id"),
  subscribedAt: timestamp("subscribed_at"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Products
export const products = pgTable("products", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url").notNull(),
  currentPrice: real("current_price").notNull(),
  originalPrice: real("original_price").notNull(),
  inStock: boolean("in_stock").default(true),
});

export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// Price Locks - saves price at time of subscription
export const priceLocks = pgTable("price_locks", {
  id: varchar("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  productId: varchar("product_id").notNull(),
  lockedPrice: real("locked_price").notNull(),
  lockedAt: timestamp("locked_at").notNull(),
});

export const insertPriceLockSchema = createInsertSchema(priceLocks).omit({ id: true });
export type InsertPriceLock = z.infer<typeof insertPriceLockSchema>;
export type PriceLock = typeof priceLocks.$inferSelect;

// Cart Items
export const cartItems = pgTable("cart_items", {
  id: varchar("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  productId: varchar("product_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  priceAtAdd: real("price_at_add").notNull(),
});

export const insertCartItemSchema = createInsertSchema(cartItems).omit({ id: true });
export type InsertCartItem = z.infer<typeof insertCartItemSchema>;
export type CartItem = typeof cartItems.$inferSelect;

// Orders
export const orders = pgTable("orders", {
  id: varchar("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  total: real("total").notNull(),
  savings: real("savings").notNull(),
  status: text("status").notNull().default("completed"),
  createdAt: timestamp("created_at").notNull(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({ id: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

// Order Items
export const orderItems = pgTable("order_items", {
  id: varchar("id").primaryKey(),
  orderId: varchar("order_id").notNull(),
  productId: varchar("product_id").notNull(),
  productName: text("product_name").notNull(),
  quantity: integer("quantity").notNull(),
  pricePaid: real("price_paid").notNull(),
  marketPrice: real("market_price").notNull(),
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({ id: true });
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

// Extended types for frontend use
export type ProductWithPriceLock = Product & {
  lockedPrice?: number;
  savings?: number;
  savingsPercent?: number;
};

export type CartItemWithProduct = CartItem & {
  product: Product;
  lockedPrice?: number;
  effectivePrice: number;
  savings: number;
};

export type UserWithSubscription = User & {
  subscription?: SubscriptionTier;
};
